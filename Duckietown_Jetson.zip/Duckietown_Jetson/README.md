# Duckietown_Jetson
This is the repo for Duckietown Jetson.

# Notice
This repo is keep building.

Please update files with:
```bash
cd ~/Project/ROS/Duckietown_Jetson
git add .
git commit -m "Update files"
git push origin main
```
