## dt-joystick

> Launch the `joy` package from the [joystick_drivers](https://github.com/ros-drivers/joystick_drivers) repository, with the desired settings. Remaps the published topic for the `joy_mapper` node.
