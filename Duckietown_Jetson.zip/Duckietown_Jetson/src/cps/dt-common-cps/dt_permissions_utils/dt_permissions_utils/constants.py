PERMISSIONS_DIR = "/data/config/permissions/"
