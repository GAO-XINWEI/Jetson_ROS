"""
    This is the Adafruit I2C library. We are not maintaining nor documenting it.
"""

from .Adafruit_I2C import Adafruit_I2C
from .Adafruit_PWM_Servo_Driver import PWM
